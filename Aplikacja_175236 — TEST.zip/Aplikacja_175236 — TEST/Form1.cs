namespace Aplikacja_175236
{
    public partial class Form1 : Form
    {
        private Lista bazaUtworow = new Lista();
        private Lista kolejkaUtworow = new Lista();

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            PobierzUtwory();
            Refresh();
        }
        private void PobierzUtwory()
        {
            bazaUtworow.Add(new Utwor("Disney", "Kizo", "Disco Polo"));
            bazaUtworow.Add(new Utwor("Monster", "Skillet", "Rock"));
            bazaUtworow.Add(new Utwor("Nikt mi tego nie da�, nikt mi tego nie zabierze", "M�ody", "Hip-Hop"));
            bazaUtworow.Add(new Utwor("Sonne", "Rammstein", "Metal"));
            bazaUtworow.Add(new Utwor("Crank That", "Soulja Boy", "Rap"));
            bazaUtworow.Add(new Utwor("All Eyez On Me", "2Pac", "Rap"));
            bazaUtworow.Add(new Utwor("Balues Licht", "RAF Camora", "Hip-Hop"));
            bazaUtworow.Add(new Utwor("Hypnotize", "B.I.G", "Hip-Hop"));
            bazaUtworow.Add(new Utwor("Low", "Flo Rida", "Hip-Hop"));
            bazaUtworow.Add(new Utwor("Le�mian", "Avi", "Rap"));
            bazaUtworow.Add(new Utwor("Przez Twe Oczy Zielone ", "Akcent", "Disco Polo"));
        }

        private void Refresh()
        {
            Baza.DataSource = null;
            Baza.DataSource = bazaUtworow.ToList();
            Baza.DisplayMember = "ToString";

            Kolejka.DataSource = null;
            Kolejka.DataSource = kolejkaUtworow.ToList();
            Kolejka.DisplayMember = "ToString";
        }

        private void dodajDoKolejkiButton_Click(object sender, EventArgs e)
        {
            if(Baza.SelectedItem is Utwor wybranyUtwor)
            {
                kolejkaUtworow.Add(wybranyUtwor);
                Refresh();
            }
        }

        private void usunZKolejkiButton_Click(object sender, EventArgs e)
        {
            if(Kolejka.SelectedItem is Utwor wybranyUtwor)
            {
                kolejkaUtworow.Remove(wybranyUtwor);
                Refresh();
            }
        }

        private void zaproponujUtworButton_Click(object sender, EventArgs e)
        {
            var kolejkaList = kolejkaUtworow.ToList();

            var gatunkiWKolejce = kolejkaList
                            .GroupBy(utwor => utwor.Gatunek)
                            .Select(grupa => new { Gatunek = grupa.Key, Liczba = grupa.Count() })
                            .OrderByDescending(grupa => grupa.Liczba)
                            .ToList();

            var dostepneUtwory = bazaUtworow.ToList().Where(utwor => !kolejkaList.Contains(utwor)).ToList();

            Utwor zaproponowanyUtwor = null;

            foreach (var gatunek in gatunkiWKolejce)
            {
                zaproponowanyUtwor = dostepneUtwory.FirstOrDefault(utwor => utwor.Gatunek == gatunek.Gatunek);
                if (zaproponowanyUtwor != null)
                {
                    break;
                }
            }

            if (zaproponowanyUtwor == null)
            {
                zaproponowanyUtwor = dostepneUtwory.FirstOrDefault();
            }

            if (zaproponowanyUtwor != null)
            {
                proponowanyUtworLabel.Text = zaproponowanyUtwor.ToString();
            }
            else
            {
                proponowanyUtworLabel.Text = "Brak dost�pnych utwor�w do zaproponowania.";
            }
        }
    }
}

