﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplikacja_175236
{
    internal class Lista
    {
        private Node head;

        public void Add(Utwor utwor)
        {
            var newNode = new Node(utwor);

            if(head == null)
            {
                head = newNode;
            }
            else
            {
               var current = head;
                
               while(current.Next != null)
                {
                    current = current.Next;
                }
               current.Next = newNode;
            }
        }

        public void Remove(Utwor utwor)
        {
            if(head == null)
            {
                return;
            }

            if(head.Data.Equals(utwor))
            {
                head = head.Next;
                return;
            }

            var current = head;

            while(current.Next != null && !current.Next.Data.Equals(utwor))
            {
                current = current.Next;
            }

            if(current.Next != null)
            {
                current.Next = current.Next.Next;
            }
        }

        public List<Utwor> ToList()
        {
            var list = new List<Utwor>();
            var current = head;

            while(current != null)
            {
                list.Add(current.Data);
                current = current.Next;
            }

            return list;
        }

        public override string ToString()
        {
            var elementy = new StringBuilder();
            var current = head;

            while(current != null)
            {
                elementy.Append(current.Data.ToString());
                current = current.Next;
            }

            return elementy.ToString();
        }

    }
}
